#!/bin/bash

CONFIG="observer.conf"
LOG="observer.log"

while IFS= read -r script;
do
    [[ -z "$script" || "$script" =~ ^# ]] && continue
    
    if ! pgrep -f "$script" > /dev/null; then
        nohup "./$script" > /dev/null 2>&1 &
        echo "$(date '+%Y-%m-%d %H:%M:%S') $script перезапущен" >> "$LOG"
    fi
done < "$CONFIG"
