#!/bin/bash

mkdir -p /tmp/run/
mkfifo /tmp/run/cuckoo.pid
trap 'echo "$(date "+%Y-%m-%d %H:%M:%S") Shutdown!" >> cuckoo.log; rm /tmp/run/cuckoo.pid; exit' SIGTERM

echo "$(date "+%Y-%m-%d %H:%M:%S") Startup!" >> cuckoo.log

while true; do
    read msg < /tmp/run/cuckoo.pid
    if [[ $msg =~ ^([^[]+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
        name="${BASH_REMATCH[1]}"
        pid="${BASH_REMATCH[2]}"
        n=$((RANDOM % 9 + 2))
        echo "$(date "+%Y-%m-%d %H:%M:%S") $name[$pid] $n" >> cuckoo.log
    fi
done
