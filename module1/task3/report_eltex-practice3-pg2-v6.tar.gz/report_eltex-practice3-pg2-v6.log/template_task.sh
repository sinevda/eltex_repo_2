#!/bin/bash

NAME=$(basename "$0")

if [ "$NAME" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

LOG_FILE="report_${NAME}.log"

echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт запущен" >> "$LOG_FILE"

CUCKOO_PIPE="/tmp/run/cuckoo.pid"
if [ ! -p "$CUCKOO_PIPE" ]; then
    echo "Ошибка: канал cuckoo не найден" >> "$LOG_FILE"
    exit 1
fi

echo "${SCRIPT_NAME}[$$]: how much time do I have?" > "$CUCKOO_PIPE"

read N < "$CUCKOO_PIPE" 2>/dev/null

if ! [[ "$N" =~ ^[0-9]+$ ]]; then
    echo "Ошибка: получен некорректный ответ" >> "$LOG_FILE"
    exit 1
fi

sleep "$N"

echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт завершился, работал $N секунд." >> "$LOG_FILE"
